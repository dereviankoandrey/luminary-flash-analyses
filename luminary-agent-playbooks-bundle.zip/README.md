# Luminary Agent Configuration Playbooks Bundle v1.0

Complete AI agent configurations for deterministic real estate underwriting using open-weight models (Qwen, Llama, Mistral).

## Contents

### Playbooks
- `playbooks/agent-underwriting-playbook.html` — Core Underwriting Agent (#0)
- `playbooks/multi-agent-pipeline.html` — Multi-Agent Pipeline Orchestration (#1)  
- `playbooks/portfolio-analysis.html` — Portfolio-Level Analysis (#2)

### Tools (Interactive HTML)
- `tools/deal-analyzer.html` — Deterministic Deal Analyzer
- `tools/deal-screener.html` — Deal Screener Demo
- `tools/deterministic-vs-ai-comparison.html` — Determ vs AI Comparison
- `tools/safedeal-analyzer.html` — SafeDeal Risk Analyzer

### Templates & Documents
- `templates/dd-report-template.md` — Due Diligence Report Template
- `templates/fast-deal-triage-playbook.md` — Fast Deal Triage Playbook
- `docs/analysis-methodology.md` — Complete Analysis Methodology
- `docs/underwriting-framework.md` — Underwriting Framework Reference
- `briefs/sample-dd-report.md` — Sample Market Intelligence Brief

### Email Sequences
- `email-sequences/WAITLIST-NURTURE-SEQUENCE.md` — Early Access Nurture Sequence

## Quick Start

1. Open any `.html` file in your browser — works offline, no setup required
2. Read the playbooks for agent configuration guidance
3. Use Python scripts (included below) to deploy automated underwriting agents

## Requirements

- Modern web browser (Chrome, Firefox, Safari, Edge)
- For agent deployment: Ollama installed locally
- Recommended GPU: RTX 3060+ (12GB VRAM for full pipeline)

## License

Free to use. Attribution appreciated but not required. Built by Luminary Ventures.

---
*Produced through 174+ nights of autonomous real estate deal analysis.*
